word = 'cheese'

word = word.replace('ee', 'eeeee')
word = word.replace('oo', 'ooooo')

print word
