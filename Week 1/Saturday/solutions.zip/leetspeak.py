word = raw_input('The word: ').upper()

# A => 4
# E => 3
# G => 6
# I => 1
# O => 0
# S => 5
# T => 7

word = word.replace('A', '4')
word = word.replace('E', '3')
word = word.replace('G', '6')
word = word.replace('I', '1')
word = word.replace('O', '0')
word = word.replace('S', '5')
word = word.replace('T', '7')

print word
