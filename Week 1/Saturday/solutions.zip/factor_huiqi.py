n = int(raw_input("what's the number?"))

for i in range(1, n):
   if n % i == 0:
       print str(n/i)

print "1"
