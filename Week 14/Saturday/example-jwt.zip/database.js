// Fake database of users
let users = {
  'joe@smith.com': {
    id: 3,
    email: 'joe@smith.com', // superpass
    password: '$2a$10$QxXI6cAM.zQbzTlX4Wk6oey7/UOb70AGUqEFCIZCJucNeAyQjaOIS',
  },
  'joe@bloggs.com': {
    id: 5,
    email: 'joe@bloggs.com', // differentpass
    password: '$2a$10$kUD9/fYNDBVlTzdpJh0OM.CuLyW6splbmOx7SlpRUC2LSsLb5zo2y',
  },
};

let findUserByEmail = email => users[email];

module.exports = {
  findUserByEmail
};
