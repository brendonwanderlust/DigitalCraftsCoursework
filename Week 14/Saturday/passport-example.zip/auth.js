const passport = require('passport');
const GitHubStrategy = require('passport-github').Strategy;
const session = require('express-session');
const cookieParser = require('cookie-parser');
const User = require('./models/user');

const setupAuth = (app) => {
    app.use(cookieParser());

    app.use(session({
        secret: 'secretserverword',
        resave: true,
        saveUninitialized: true,
    }));

    passport.use(new GitHubStrategy({
        clientID: "9353d327defc48661050",
        clientSecret: "dac4a0ebe0fc0eb2040b106f62afe827ca8e82aa",
        callbackURL: "http://localhost:3000/github/auth"
    }, (accessToken, refreshToken, profile, done) => {
        User.findOrCreate({
            where: {
                github_id: profile.id
            }
        })
        .then(result => {
            return done(null, result[0]);
        })
        .catch(err => { // .catch(done);
            done(err);
        })
    }))

    passport.serializeUser((user, done) => {
        done(null, {
            id: user.id,
            firstname: 'Test',
            lastname: 'Example',
        })
    });

    passport.deserializeUser((user, done) => {
        done(null, user);
    })

    app.use(passport.initialize());

    app.use(passport.session());

    app.get('/login', passport.authenticate('github'));

    app.get('/logout', (req, res, next) => {
        req.logout();
        res.redirect('/');
    })

    app.get('/github/auth',
        passport.authenticate('github', {
            failureRedirect: '/login'
        }),
        (req, res) => {
            res.redirect('/');
        }
    )
}

const ensureAuthenticated = (req, res, next) => {
    if (req.isAuthenticated()) {
        return next();
    }
    res.redirect('/login');
}

module.exports = setupAuth;
module.exports.ensureAuthenticated = ensureAuthenticated;
