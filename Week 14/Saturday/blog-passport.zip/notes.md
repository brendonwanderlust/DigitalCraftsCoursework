

# handlebars

- `npm install express-handlebars`
- `mkdir views`
- `cd views/`
- `touch home.hbs`
- `mkdir layouts`
- `touch layouts/layout.hbs`


