const dotenv = require('dotenv');
const Sequelize = require('sequelize');

dotenv.load();
const db = {
  pass: process.env.POSTGRES_PASS,
  user: process.env.POSTGRES_USER,
  host: process.env.POSTGRES_HOST,
  name: process.env.POSTGRES_DB_NAME,
}
const sequelize = new Sequelize(`postgres://${db.user}:${db.pass}@${db.host}:5432/${db.name}`);

module.exports = sequelize;

// sequelize
//   .authenticate()
//   .then(() => {
//     console.log('That totally connected. yeah!');
//   })
//   .catch((err) => {
//     console.error('Oh noes that did not work. :(')
//   });



// User.sync()
//   .then(() => {
//     console.log('It should have created the table.');
//     return User.create({
//       firstName: 'Chris',
//       lastName: 'Aquinoooooooooooo'
//     });
//   });

// User.findOne({
//   where: {
//     id: 1
//   }
// })
// .then((me) => {
//    console.log(me);
// });




