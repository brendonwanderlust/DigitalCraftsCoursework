var express = require('express');
var router = express.Router();

const fs = require('fs');
const util = require('util');
const readFile = util.promisify(fs.readFile);


/* GET home page. */
router.get('/', function(req, res, next) {

  // read the blog posts from the file
  readFile('blog-posts.json')
    .then((data) => {
      const blogPosts = JSON.parse(data);

      let dataForTemplate = {
        title: 'Panda Express',
        myName: 'chris aquinooooooooooooo',
        cats: ['oakley', 'milla'],
        posts: blogPosts
      };

      return dataForTemplate;
    })
    .then((templateData) => {

      // here is where i res.render
      res.render('index', templateData);

    }).catch(err => {
      console.log(err);
    })




});

router.get('/:postId', (req, res, next) => {
  readFile('blog-posts.json')
    .then((data) => {


      const blogPosts = JSON.parse(data);
      const id = req.params.postId;
      const thePost = blogPosts[id];

      console.log("the id is: " + id);
      console.log("here is the post: " + JSON.stringify(thePost));

      return thePost;
    })
    .then((blogPostData) => {

      // here is where i res.render
      res.render('blog-post', blogPostData);

    }).catch(err => {
      console.log(err);
    })
});

module.exports = router;
