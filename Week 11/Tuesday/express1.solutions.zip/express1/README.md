# Example 1

This is the example project we did in class around products, with some improvements. Look through this code and the comments. Your task is to implement the DELETE verb using all the hints in the source code to discover what you need to do.

To run the code, remember you need to ```cd``` into the root directory of the application and run ```npm install```. To run the program and test your changes, you need to execute ```npm start``` then use a browser and postman to hit the server--which should be operating on port 3000.